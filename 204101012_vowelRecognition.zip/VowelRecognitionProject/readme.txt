========================================================================
    CONSOLE APPLICATION : VowelRecognitionProject Project Overview
========================================================================

This file contains a summary of what you will find in each of the files that
make up your VowelRecognitionProject application.

Run MainFile.cpp to execute the project

Recordings folder will contain 100 recordings of 5 vowels 20 files each

Recording Module has also been implemented in this project so that we can recognize 
the vowel spoken live


/////////////////////////////////////////////////////////////////////////////
